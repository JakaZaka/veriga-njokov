// Remove this file as ClothingCategory is defined in ClothingItem.kt.
